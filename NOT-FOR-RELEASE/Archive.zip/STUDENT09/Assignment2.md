# Inventory Management System with PostgreSQL

## Student Name
Akylai Davletova
adavletova@usf.edu

## Overview
This document presents SQL scripts and approach for designing an efficient inventory management system using PostgreSQL's hash partitioning. The designed inventory table uses hash partitioning based on the `item_id` column. The inventory table features attributes such as `item_id`, `item_name`, `quantity`, `category`, and `warehouse_id`, with `item_id` serving as the primary key. Hash partitioning is implemented with two partitions, `inventory_part1` and `inventory_part2`, distributing rows based on a modulus of 2 and remainders 0 and 1, respectively.

My assumptions included analysing `item_id` suitability for hash partitioning, `quantity` representing current stock, and `warehouse_id` serving as a unique identifier. These assumptions align with typical inventory management practices, which allows us to effectively partition tables and provide meaningful representation of the data.

## SQL Scripts
```
1. Design an Inventory Table:
CREATE TABLE inventory (
    item_id INTEGER PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER)PARTITION BY HASH (item_id);

2. Implement Hash Partitioning:
CREATE TABLE inventory_part1 
    PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2 
    PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);

3. Insert Sample Data:
INSERT INTO inventory (item_id,item_name, quantity, category, warehouse_id) VALUES
    (1,'Laptop', 100, 'Electronics', 1),
    (2,'Jacket', 50, 'Clothing', 2),
    (3,'Phone', 200, 'Electronics', 1),
    (4,'Jeans', 75, 'Clothing', 2),
    (5,'Microwave', 150, 'Electronics', 1);
	
4. Querying the Data:
SELECT * FROM inventory WHERE category = 'Electronics';

SELECT * FROM inventory_part1 where item_id = '2';

SELECT 'inventory_part1' AS partition_name, COUNT(*) AS item_count FROM inventory_part1
    UNION
SELECT 'inventory_part2' AS partition_name, COUNT(*) AS item_count FROM inventory_part2;
```
