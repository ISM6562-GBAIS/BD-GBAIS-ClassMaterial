# Creating a Partitioned Inventory Table in PostgreSQL

### Document Information
**Author** Nikita Gill <br>
**ID** U49022008 <br>
**Date** 25 Feb 2024 

## Description
This document outlines the process of creating an inventory table and implementing hash partitioning in postgress database. Through the provided SQL scripts and queries, we will understand how hash partitioning is applied to distribute data across partitions based on a hashing mechanism. By examining the results of queries, we will discuss at the end on the effectiveness of partitioning in terms of data distribution and performance impact.

## Approach while designing the table
I am taking a structured approach while designing the inventory system. Firstly we deteremined the Determine the columns needed to store inventory data. Then we assign appropriate data types for each column based on the nature of the data and expected values. I used some constraints to enforce data integrity like the primary key constraints, NOT NULL constraints on some columns. Then we use Hash partitioning method to create 2 partitions in the table. Moreover, we query the data with the objective of fast execution due to partitioning, leveraging the distributed nature of partitions to improve query performance and enhance overall system efficiency.

## Assumptions made while designing the table
- It's assumed that the data distribution across the "item_id" column is relatively uniform.
- Hash partitioning will help distribute the data evenly across partitions, aiding in better performance and management of the inventory data.
- Hash partitioning is assumed to provide scalability benefits by enabling the system to handle growing volumes of inventory data effectively. The assumption is that as the dataset expands, hash partitioning will continue to distribute data evenly across partitions, ensuring that performance remains consistent.

## Step 1 : Desiging an Inventory Table

**Table Name:** inventory <br>
**Table Columns:**
- item_id (integer): A unique identifier for each inventory item.
- item_name (text): The name of the inventory item.
- quantity (integer): The quantity of the item currently in stock.
- category (text): The category to which the item belongs (e.g., electronics, clothing).
- warehouse_id (integer): An identifier for the warehouse where the item is stored.

**Partitioning method** <br>
We will use HASH partitioning method and will partition the table by hashing the item_id.

**SQL script** to create the inventory table with partition:

```sql
CREATE TABLE inventory (
    item_id SERIAL PRIMARY KEY,    
    item_name TEXT NOT NULL,       
    quantity INTEGER NOT NULL,    
    category TEXT NOT NULL,        
    warehouse_id INTEGER NOT NULL  
)
PARTITION BY HASH(item_id);        -- Partition the table by hashing the item_id
```
Upon executing the script, the inventory table is created in the database with 5 columns and the table will be partitioned using hash partitioning based on the "item_id" column. Now we will proceed to create the two partitioned tables.

## Step 2 : Implementing Hash Partitioning

We will create two partitions of the main inventory table. Through the implementation the hash method distributes the data across the partitions based on the result of a hash function applied to the "item_id" column.

- **inventory_part1** stores items where the "item_id" is divisible by 2 without any remainder.
- **inventory_part2** stores items where the "item_id" is not divisible by 2.

**SQL script** to create the partitioned table:

```sql
CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);
CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);
```
Upon executing the provided SQL script, two partitions of the inventory table named "inventory_part1" and "inventory_part2" will be created using hash partitioning based on the item_id column.

## Step 3 : Inserting Sample Data

Now, let's insert 10 records into the inventory table. These records will be automatically distributed across the two partitions based on the hash of the item_id.

**Automatic Data Distribution Based on Hash of item_id :**
When each row is inserted, the hash value of its item_id is computed. This hash value determines which partition the row will be placed into. For example, if the hash value is even, the row will be inserted into inventory_part1, and if it's odd, it will be inserted into inventory_part2.

**SQL script** to insert records into the inventory table:

```sql
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES
('Smartphone 1', 50, 'Electronics', 1),
('Smartphone 2', 60, 'Electronics', 2),
('Laptop 1', 40, 'Electronics', 3),
('Laptop 2', 35, 'Electronics', 1),
('T-shirt 1', 70, 'Clothing', 2),
('T-shirt 2', 80, 'Clothing', 3),
('Jeans 1', 45, 'Clothing', 1),
('Jeans 2', 55, 'Clothing', 2),
('Microwave Oven 1', 30, 'Home & Kitchen', 3),
('Microwave Oven 2', 35, 'Home & Kitchen', 1);
```

## Step 4 : Querying the Data

**Selecting items from a specific category across all partitions:**
The first query selects all columns from the "inventory" table where the category matches the specified value ('Clothing'). This query retrieves all items belonging to the 'Clothing' category from across all partitions.

**SQL script** to select items:

```sql
SELECT *
FROM inventory
WHERE category = 'Clothing'; 
```
Upen executing the script we got 4 records . 

**Counting the number of items in each partition:**
Below query counts the number of items in "inventory_part1", and the number of items in "inventory_part2".

**SQL script** to count items:

```sql
Below is the  query to count the number of items in each partition.
SELECT COUNT(*) FROM inventory_part1;
SELECT COUNT(*) FROM inventory_part2;
```
Upen executing the script we got 2 records in the first partition - inventory_part1 and 8 records in the second partition- inventory_part2.

## Discussion
**Results and Observations** <br>
Upon executing the script, it was observed that there were 2 records in the first partition, "inventory_part1," and 8 records in the second partition, "inventory_part2". This result indicates an uneven distribution of records across the partitions, despite the implementation of hashing in PostgreSQL for partitioning.

The uneven distribution of records can be attributed to the nature of the hashing mechanism used for partitioning. While hash partitioning aims to distribute data evenly across partitions based on the hash of the partitioning column (in this case, the item_id column), it does not guarantee perfectly equal distribution, especially with a small dataset like the one we inserted.

Additionally, hash partitioning relies on the hash function's ability to uniformly distribute data across partitions. If the hash function does not evenly distribute values or if there are patterns in the data that result in skewness, the distribution across partitions may not be uniform.

**Performance Impact** <br>
When we executed the query to select items for a category across all partitions, we observe here that partition with fewer records may execute the query more quickly, while the partition with more records may require additional processing time. This can result in overall longer query execution times and uneven workload distribution across partitions.

