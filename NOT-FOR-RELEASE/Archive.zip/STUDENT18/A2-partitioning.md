# Inventory Management System

## Author: Sharvari More

## Overview

This document presents the design and implementation of an inventory table with hash partitioning using SQL

## Table Structure
- Columns:
  - item_id
  - item_name
  - quantity
  - category
  - warehouse_id
  
## Hash Partitioning
- Partitioning based on the item_id column.
- Two partitions created for even data distribution.

## Sample Data
- Inserted data for fruits and clothing items 
- Determined queries for selecting items from a specific category and counting items within each partition.

## SQL Scripts

### Create inventory table
```sql
CREATE TABLE inventory (
	item_id INT PRIMARY KEY,
	item_name TEXT,
	quantity  INT,
	category TEXT,
	warehouse_id INT
) PARTITION BY HASH (item_id);
```

### Create partitions
```sql
CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);
CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);
```

### Insert sample data
```sql
INSERT INTO inventory values (1, 'Apple', 10, 'Fruits', 1);
INSERT INTO inventory values (2, 'Skirt', 20, 'Clothing', 2);
INSERT INTO inventory values (3, 'Orange', 15, 'Fruits', 1);
INSERT INTO inventory values (4, 'Jacket', 25, 'Clothing', 2);
INSERT INTO inventory values (5, 'Kiwi', 12, 'Fruits', 1);
```

### Query to select all items from a specific category across all partitions
```sql
SELECT * FROM inventory WHERE category = 'Fruits';
```

### Count the number of items in each partition
```sql
SELECT
	'inventory_part1' AS partition,
	COUNT(*) AS item_count
FROM inventory_part1
UNION ALL
SELECT
	'inventory_part2' AS partition,
	COUNT(*) AS item_count
FROM inventory_part2;
```

## Assumption
- The `item_id` is assumed to be a unique identifier for each inventory item.

## Table Design
- Essential Columns:
  - item_id (unique identifier)
  - item_name
  - quantity
  - category
  - warehouse_id
  
## Partitioning Strategy
- Hash partitioning based on the `item_id` column.
- Goal: Ensure even data distribution across partitions.

## Purpose of Chosen Columns
- Capture key information about each inventory item:
    - Name
    - Quantity
    - Category
    - Warehouse association
  
## Query Performance Enhancement
- By partitioning the table:
    - Facilitates parellel processing.
    - Enhances data retreival efficiency.