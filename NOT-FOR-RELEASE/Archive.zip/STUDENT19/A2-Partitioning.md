# A2-Partitioning
## Presented by: Rodgers Okeyo Ochieng
## Professor: Dr Timothy Smith
## Class: Big Data
## School: Muma School of Business University of South Florida

### Explanation

In this exercise, I began by creating the warehouse table since I needed the warehouse id to be used as the secondary key of the inventory table. I made the warehouse id to be an integer instead of serial since I would use it as a secondary key. 

I then created the inventory table and all the column names in it. partitioning it with hash partitioning using the inventory id which would be the primary key. 

From here I created two partitions by alternating the inputs. all the inventory with a modulus of 0 went to the inventory_part1 partition while those with a modulus of 1 went to the partition 2. From here, I inserted the data into the inventory table and the data was automatically partitioned based on their inventory_id.



--Create the warehouse table
CREATE TABLE warehouse(
	warehouse_id INTEGER PRIMARY KEY,
	warehouse_name TEXT NOT NULL
);

-- Create the inventory table partitioning by the item_id
CREATE TABLE inventory(
	item_id SERIAL PRIMARY KEY,
	item_name TEXT NOT NULL,
	quantity INTEGER,
	category TEXT,
	warehouse_id INTEGER REFERENCES warehouse(warehouse_id)

) PARTITION BY HASH(item_id);

--Create the partitions
CREATE TABLE inventory_part1 PARTITION OF inventory
FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2 PARTITION OF inventory
FOR VALUES WITH (MODULUS 2, REMAINDER 1);

--Insert the warehouse data first
INSERT INTO warehouse (warehouse_id, warehouse_name) VALUES
(1, 'Tampa'),
(2, 'Naples'),
(3, 'Nairobi');

--Insert the inventory
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES
('Item 1', 100, 'Category A', 1),
('Item 2', 150, 'Category B', 1),
('Item 3', 200, 'Category C', 2),
('Item 4', 250, 'Category D', 2),
('Item 5', 300, 'Category E', 1),
('Item 9', 150, 'Category B', 1),
('Item 11', 200, 'Category C', 2),
('Item 41', 250, 'Category D', 2),
('Item 15', 300, 'Category E', 1);

-- Select all items in the inventory table from Category D
SELECT *
FROM inventory
WHERE category ='Category D';


-- Count the number of items in inventory_part1
SELECT 'inventory_part1' AS partition, COUNT(*) AS item_count
FROM inventory_part1;

-- Count the number of items in inventory_part2 Deselect this when needed
--SELECT 'inventory_part2' AS partition, COUNT(*) AS item_count
--FROM inventory_part2;
