# Partitioning Assignment - Inventory Table creation

## Author: Divya Sakhare

## Introduction  
This document outlines the design and implementation of an efficient Inventory Management System using PostgreSQL's table partitioning feature. The primary objective is to enhance the scalability and performance of the system by employing hash partitioning on the inventory table.

### Table Design  
inventory Table  
item_id (integer): A unique identifier for each inventory item.  
item_name (text): The name of the inventory item.  
quantity (integer): The quantity of the item currently in stock.  
category (text): The category to which the item belongs (e.g., electronics, clothing).  
warehouse_id (integer): An identifier for the warehouse where the item is stored.  

### Partitioning Strategy  
The inventory table is partitioned using the hash method based on the item_id column. Two partitions, namely inventory_part1 and inventory_part2, are created to distribute data evenly and improve query performance.

## SQL Script: 

### 1. Create Partitioned Table using Hash Partitioning    
```sql
-- SQL script for creating the partitioned table


CREATE TABLE inventory (
    item_id SERIAL PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
)PARTITION BY HASH(item_id);

-- Create partitions
CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);
CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);

```

### 2. Insert Sample Data into Invertory table

```sql
-- Insert sample data into the inventory table
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES
    ('Fruit1', 10, 'Apple', 1),
    ('Fruit2', 20, 'Banana', 2),
    ('Fruit3', 15, 'Apple', 1),
    ('Fruit4', 5, 'Banana', 2),
    ('Fruit5', 25, 'Apple', 1);

```

### 3. Query Data

```sql
-- Query to select all items from a specific category across all partitions
SELECT * FROM inventory WHERE category = 'Banana';

-- Query to count the number of items in each partition
SELECT
    'inventory_part1' AS partition_name,
    COUNT(*) AS item_count
FROM inventory_part1
UNION
SELECT
    'inventory_part2' AS partition_name,
    COUNT(*) AS item_count
FROM inventory_part2;


-- Query to select all items from inventory_part1
SELECT * from inventory_part1;

-- Query to select all items from inventory_part1
SELECT * from inventory_part2;

```

### Approach and Assumptions  
The approach taken involves creating a hash-partitioned table based on the item_id column to evenly distribute data and enhance query performance. Two partitions are created, and sample data is inserted to showcase the partitioning mechanism.

### Assumptions:

- The item_id column is suitable for hash partitioning.
- The system is expected to handle a moderate-sized inventory dataset.
- The provided sample data is for illustrative purposes and may not reflect a real-world scenario.
