# Inventory Table Partitioning Assignment

## Author: Akshata Salunkhe 

## Approach:  
In designing the inventory management system with hash partitioning in PostgreSQL, I followed a structured approach to achieve scalability and performance improvements. Here are the key aspects of my approach:

1. Table Design:  
I created the main table named inventory to store information about inventory items, including item_id, item_name, quantity, category, and warehouse_id. The choice of columns was based on the need for a comprehensive representation of inventory data.

2. Hash Partitioning:  
To enhance performance and scalability, I opted for hash partitioning using the item_id column. This involved creating two partitions: inventory_part1 and inventory_part2. The use of MODULUS and REMAINDER values in the partition creation ensures a relatively even distribution of data among the partitions.

3. Sample Data Insertion:  
I inserted sample data into the inventory table to demonstrate the automatic distribution of data across partitions based on the hash values of item_id. This allowed me to showcase the effectiveness of hash partitioning in action.

4. Querying the Data:  
I formulated queries to select items from a specific category across all partitions and to count the number of items in each partition. This enabled me to verify the expected behavior of hash partitioning in query scenarios.

Assumptions:  
While implementing the solution, I made the following assumptions:

The item_id column serves as a suitable candidate for hash partitioning, providing a balanced distribution.
The hash function provided by PostgreSQL for hash partitioning offers uniform data distribution.iption: 


## SQL Script: 

### 1. Create Partitioned Table
```sql
-- SQL script for creating the partitioned table


CREATE TABLE inventory (
    item_id SERIAL PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
)PARTITION BY HASH(item_id);

-- Create partitions
CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);
CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);

```

### 2. Insert Sample Data

```sql
-- Insert sample data into the inventory table
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES
    ('Ice-cream1', 10, 'Vanila', 1),
    ('Ice-cream2', 20, 'Chocalate', 2),
    ('Ice-cream3', 15, 'Vanila', 1),
    ('Ice-cream4', 5, 'Chocalate', 2),
    ('Ice-cream5', 25, 'Vanila', 1);
```

### 3. Query Data

```sql
-- Query to select all items from a specific category across all partitions
SELECT * FROM inventory WHERE category = 'Vanila';

-- Query to count the number of items in each partition
SELECT
    'inventory_part1' AS partition_name,
    COUNT(*) AS item_count
FROM inventory_part1
UNION
SELECT
    'inventory_part2' AS partition_name,
    COUNT(*) AS item_count
FROM inventory_part2;


-- Query to select all items from inventory_part1
SELECT * from inventory_part1;

-- Query to select all items from inventory_part1
SELECT * from inventory_part2;

```
