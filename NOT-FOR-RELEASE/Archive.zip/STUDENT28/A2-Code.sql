-- Create the main table
CREATE TABLE inventory (
    item_id INTEGER,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
) PARTITION BY HASH(item_id);

CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);

INSERT INTO inventory (item_id, item_name, quantity, category, warehouse_id) 
VALUES (1, 'Laptop', 50, 'Electronics', 1),
       (2, 'Smartphone', 100, 'Electronics', 1),
       (3, 'Headphones', 75, 'Electronics', 2),
       (4, 'Backpack', 200, 'Accessories', 3),
       (5, 'Mouse', 150, 'Electronics', 2);


SELECT COUNT(*)
FROM inventory_part1;

SELECT *
FROM inventory_part1;

