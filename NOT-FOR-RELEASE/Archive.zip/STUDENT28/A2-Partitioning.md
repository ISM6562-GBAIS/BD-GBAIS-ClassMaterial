
# Title : Assignment 2 Big Data : Partitioning 

This is Assignment 2 for big data for business course which will demonstrate implementation of table partitioning in Postgres tables.

We will take an example of inventory table

## Design an Inventory Table
Creating inventory table with 5 column
```SQL
CREATE TABLE inventory (
    item_id INTEGER PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
) PARTITION BY HASH(item_id);
```

## Implement Hash Partitioning

We will add 2 partition to our inventory table as inventory_part1 and inventory_part2 using Hash.

```SQL
CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);
```
## Inserting sample data
We will add 5 sample rows to check if partition working.
```SQL
INSERT INTO inventory (item_id, item_name, quantity,category, warehouse_id) 
VALUES (1, 'Laptop', 50, 'Electronics', 1),
       (2, 'Smartphone', 100, 'Electronics', 1),
       (3, 'Headphones', 75, 'Electronics', 2),
       (4, 'Backpack', 200, 'Accessories', 3),
       (5, 'Mouse', 150, 'Electronics', 2)
```

## Querying partition
We will select all values from both the partition

```SQL
SELECT *
FROM inventory_part1;
```
OUTPUT: 
| item_id | item_name | quantity | category | warehouse_id |
| -- | -- | -- | -- | -- |
| 1 | Laptop | 50 | Electronics | 1 |
| 2 | Smartphone | 100 | Electronics | 1 |
```SQL
SELECT *
FROM inventory_part2;
```
| item_id | item_name | quantity | category | warehouse_id |
| -- | -- | -- | -- | -- |
| 3 | Headphones | 75 | Electronics | 2 |
| 4 | Backpack | 200 | Accessories | 3 |
| 5 | Mouse | 150 | Electronics | 2 |


## Number of items in each partition
```SQL
SELECT COUNT(*)
FROM inventory_part1;
```

| count |
| -- |
| 2 |

```SQL
SELECT COUNT(*)
FROM inventory_part2;
```
| count |
| -- |
| 3 |

# Conclusion

The example above demonstrates the implementation of hash partitioning. 

An important observation is that the PostgreSQL algorithm considers the entire row when calculating the hash value, rather than a specific column. 

Ideally, they should be partitioned as item_id 1, 3, and 5 in one partition, and 2 and 4 in another, but in reality, items with IDs 1 and 2 are in one partition, while items with IDs 3, 4, and 5 are in another shows how algorithm works inside.