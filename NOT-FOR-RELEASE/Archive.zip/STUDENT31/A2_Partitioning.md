# Creating a Partitioned Inventory Table in PostgreSQL

## Author: Shivani Suryawanshi

## Description:
This document outlines the design and implementation of an inventory management system using PostgreSQL and table partitioning techniques. The system effectively handles inventory data for a retail store by using hash partitioning on the 'item_id' column.

## Table Creation and Partitioning:


```sql
-- Create Inventory Table by Hash Partitioned Table

CREATE TABLE inventory (
    item_id SERIAL PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
) PARTITION BY HASH (item_id);
```

```sql
-- Create Partitions

CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);
CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);
```
```sql
-- Insert Values In Table

INSERT INTO inventory (item_id,item_name, quantity, category, warehouse_id) VALUES 
    (1,'Laptop', 10, 'Electronics', 1),
    (2,'Tomato', 5, 'Vegetables', 2),
    (3,'TV', 15, 'Electronics', 1),
    (4,'Jeans', 30, 'Clothing', 2),
    (5,'Cellphone', 25, 'Electronics', 1);
```
```sql
--Querying Items from Specific Category Across Partitions

SELECT * FROM inventory WHERE category = 'Electronics';
```

```sql
--Counting Number of Items in Each Partition

SELECT 'inventory_part1' AS partition_name, count(*) AS item_count FROM inventory_part1
UNION ALL
SELECT 'inventory_part2' AS partition_name, count(*) AS item_count FROM inventory_part2;
```

## Approach and Assumptions:

## Approach:
1. Created a primary table called "inventory" with columns described in   the requirements. 
2. Implemented hash partitioning using the item_id column to equally distribute data across partitions.
3. Created two partitions, inventory_part1 and inventory_part2, to facilitate the partitioning approach.*

## Assumptions: 
1. Each inventory item is assigned a distinct item_id.
2. The warehouse_id field represents the unique identity of the warehouse where the item is located.
3. Data insertion for demonstration purposes is manually performed, ensuring equal distribution among partitions based on the hash of item_id.
