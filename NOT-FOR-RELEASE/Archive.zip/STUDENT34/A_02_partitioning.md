﻿# A2-Partitioning
Author: Jayanth Uppara
(U46027839)
02/25/2000




# Description

The design of an inventory management system is described in this document, along with steps for creating a partitioned inventory database, adding sample data, and querying the data. The system's architecture maximizes scalability and performance by effectively managing inventory items by category across several partitions.

## Table Creation Script

-- Create the main inventory table
CREATE TABLE inventory (
    item_id SERIAL PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
) PARTITION BY HASH(item_id);

-- Create partitions for the inventory table based on item_id hash
CREATE TABLE inventory_part1 PARTITION OF inventory
    FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2 PARTITION OF inventory
    FOR VALUES WITH (MODULUS 2, REMAINDER 1);
	
## Sample Data Insertion

	
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES
    ('mobile', 4, 'Electronics', 1),
    ('protien bar', 30, 'food', 2),
    ('shampoo', 20, 'beauty', 3),
    ('shirt', 20, 'Clothing', 4),
    ('coffee', 5, 'food', 2);

## Querying the Data

### Selecting Items by Category

SELECT * FROM inventory WHERE category = 'Electronics';

### Counting Items in Each Partition

SELECT 'inventory_part1' AS partition, COUNT(*) AS item_count FROM inventory_part1
UNION ALL
SELECT 'inventory_part2' AS partition, COUNT(*) AS item_count FROM inventory_part2;

## Approach and Assumptions

 - **Data Insertion:**  To ensure effective data loading, sample data is entered into the inventory table using multi-row INSERT statements. 
 
 - **Categories:**  To help with orderly inventory management, products are
   divided into discrete areas like electronics, food, beauty products,
   and clothing.
- **Warehouse IDs:** Every item has an individual warehouse ID, which makes it possible to trace the locations of items and the distribution of goods among warehouses.  
- **Item Quantities:** Essential for inventory tracking and management, the quantity field shows the available stock levels for each item.  
- **Data Consistency:** Presumptive compliance with schema requirements guarantees correct and consistent data entry, preserving data integrity.  

- **Primary Key:** The primary key for each inventory item is the item_id column, which is automatically generated to guarantee uniqueness.
