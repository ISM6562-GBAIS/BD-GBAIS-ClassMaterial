# Inventory Management System

### Author: Akshay Vijayvergiya
#### Date: 24 Feb 2024

## Description

This document provides an overview of the design and execution of an inventory management system within a relational database using SQL. It encompasses the creation of an inventory table, the application of hash partitioning, the insertion of sample data, and the querying of stored data.
Additionally, the document offers a comprehensive analysis of hash partitioning mechanics, detailing how data distribution across partitions occurs and how partitioning enhances data retrieval speed. Furthermore, it delves into the performance benefits of partitioning for large tables and small tables.

## 1. Designing the Inventory Table

### Inventory Table Structure:

- **Table Name:** inventory
- **Columns:**
  - item_id (integer): Unique identifier for each inventory item.
  - item_name (text): Name of the inventory item.
  - quantity (integer): Quantity of the item currently in stock.
  - category (text): Category to which the item belongs (e.g., electronics, clothing).
  - warehouse_id (integer): Identifier for the warehouse where the item is stored.

## 2. Implementing Hash Partitioning

### Partitioning Strategy:
Partition the inventory table using hash partitioning based on the item_id column.
Creating 2 partitions: inventory_part1 and inventory_part2.

```sql
CREATE TABLE inventory (
    item_id SERIAL PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
) PARTITION BY HASH(item_id);

CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);
CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);
```
The above created a table called `inventory` with 2 partitions `inventory_part1` and `inventory_part2`.

## 3. Inserting Sample Data

### Sample Data:

Insert at least 5 sample rows into the inventory table. The data will automatically distribute across the two partitions based on the hash of item_id.
Below is the Query to insert 10 sample rows in `inventory` table.

```sql
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Laptop', 10, 'Electronics', 1);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Desk Chair', 20, 'Furniture', 2);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('LED Bulb', 150, 'Lighting', 1);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Bluetooth Speaker', 30, 'Electronics', 3);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Notebook', 60, 'Stationery', 2);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Mouse', 25, 'Electronics', 1);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Keyboard', 30, 'Electronics', 3);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Desk Lamp', 40, 'Lighting', 1);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Bookshelf', 15, 'Furniture', 2);
INSERT INTO inventory (item_name, quantity, category, warehouse_id) VALUES ('Pen Set', 75, 'Stationery', 2);

```
In above, I tried inserting 5, 20 and 25 sample rows and did analysis on all these three combinations of Inserts. Detailed analysis is below.

## 4. Querying the Data

### Query to Select Items from a Specific Category Across All Partitions:

```sql
SELECT * FROM inventory WHERE category = 'Electronics';
```
The above Query resulted in 6 rows from the `inventory` table when there were total 20 sample rows.

### Query to Count the Number of Items in Each Partition:

```sql
SELECT count(*) as no_of_items from inventory_part1;
SELECT count(*) as no_of_items from inventory_part2;
```
The above query resulted like below in different number of sample rows,
**5 rows:** 2 rows in `inventory_part1` and 3 rows in `inventory_part2`
**20 rows:** 9 rows in `inventory_part1` and 11 rows in `inventory_part2`
**25 rows:** 10 rows in `inventory_part1` and 15 rows in `inventory_part2`

## Mechanism

### Hash Partitioning Mechanism

Hash partitioning involves dividing data into multiple partitions based on a hash function applied to a specified column, such as item_id in our case. This method ensures that data is distributed evenly across partitions, optimizing storage and retrieval efficiency.

### Data Allocation to Partitions

When inserting data into the inventory table, the hash function is applied to the item_id column. Based on the hash value, each row is allocated to a specific partition. For example, rows with even hash values may go to one partition, while rows with odd hash values may go to another.

## Detailed Analysis

### Approach & Assumption

- **Partitioning Approach:** The inventory table is partitioned using a hash method on item_id to ensure an even distribution of data across partitions, which can enhance query performance and data management, especially when dealing with large datasets.
- **Partitions:** Two partitions (inventory_part1 and inventory_part2) are created with the assumption that a modulus of 2 (for splitting by hash) will suffice for demonstration purposes. This evenly distributes items based on the item_id's hash value. But this is not the case always. We have seen in our analysis there are some cases where the distribution is not even at all. 
- **Sample Data Insertion:** The sample data covers a range of items across different categories and warehouses to illustrate how data will be distributed across partitions.
- **Querying Data:** The provided queries demonstrate how to retrieve items by category across all partitions and how to count items in each partition, acknowledging that direct partition-wide aggregations require individual queries per partition.

### More Analysis on certain Questions
**1. Does hash partitioning always guarantee equal distribution of rows across different partitions?**\
Hash partitioning does not always guarantee an equal distribution of rows across different partitions. In  our case, we tried inserting three different number of rows at a time to study distribution:

> **20 rows:** We saw that 9 rows were inserted in `inventory_part1` and then 11 rows were inserted in `inventory_part2`.

> **25 rows:** We saw that 10 rows were inserted in `inventory_part1` and then 15 rows were inserted in `inventory_part2`.

> **5 rows:**  We saw two different pattern of distribution. At first, 2 rows were inserted in `inventory_part1` and then 3 rows were inserted in `inventory_part2` and then tried hitting the same 5 rows to the table and noticed that this time 4 rows were inserted in `inventory_part1` and then 1 rows were inserted in `inventory_part2`.

We can see here that it doesn't guarantee an equal distribution of rows across different partitions. The effectiveness of hash partitioning in evenly distributing data depends on several factors:
- Hash Function: The hash function's ability to produce a uniform distribution of hash values for the dataset is crucial. If the hash function does not distribute hash values evenly for the input data, some partitions may end up with more data than others.
- Number of Partitions: The choice of the number of partitions also plays a role. If the number of partitions is not well-chosen with respect to the data and the hash function, it can lead to an imbalance in data distribution.

To mitigate these issues, careful planning and testing are necessary. This includes choosing a suitable hash function, analyzing the data for potential skew, and possibly using techniques like salting (adding a random value to inputs to vary the hash output) to help distribute data more evenly. In some cases, other partitioning strategies (such as range partitioning or list partitioning) might be more appropriate depending on the nature of the data and the application's requirements.

**2. Even if partitions having different number of records in postgresql, the size showing in pgadmin is same for both of the partitions, why and how?**\
In PostgreSQL, when you observe the same size for partitions with a different number of records through tools like pgAdmin, it's typically due to how PostgreSQL manages disk space and reports the size of relations (tables and partitions). We tried running the below query to get the size of the partitions:

```sql
SELECT pg_size_pretty(pg_total_relation_size('inventory_part1')) AS part1_size,
       pg_size_pretty(pg_total_relation_size('inventory_part2')) AS part2_size;
```

The above showed same size for both of the different partitions in case of 3 different combinations of rows inserted that is 5 rows, 20 rows, 25 rows and also with 500+ rows. Here are a few reasons why this might be the behavior:
- Disk Space Allocation: PostgreSQL allocates disk space in blocks. A newly created partition, even if it doesn't contain any data, will still occupy disk space for its metadata and potentially for the initial allocation of blocks.
- Free Space and Dead Tuples: PostgreSQL uses a mechanism called Multiversion Concurrency Control (MVCC), which can result in multiple versions of a row being stored simultaneously. When rows are updated or deleted, the old versions of the rows (dead tuples) are not immediately physically removed from disk; they are marked for reuse. 
- Caching and Reporting Delays: Tools like pgAdmin may cache certain information or rely on statistics that are not updated in real-time, leading to discrepancies between the reported sizes and the actual disk usage.

### Issues in Hash Partitioning
- **Data Skew:** If the data distribution is not uniform or if the hash function does not distribute the rows evenly across partitions, some partitions may become significantly larger than others. This data skew can lead to uneven load and performance degradation, as some partitions may become hotspots for reads and writes.
- **Repartitioning Overhead:** If the number of partitions needs to be changed (due to growth or other factors), this can be a complex and costly operation. Repartitioning a table to increase or decrease the number of hash partitions typically requires redistributing the data, which can be a time-consuming process involving significant downtime.
- **Difficulty in Query Optimization for Range Queries:** Hash partitioning is not well-suited for range queries that span multiple partitions. Since hash partitioning distributes rows based on the hash value of the partition key, rows with adjacent key values can end up in different partitions. This can lead to inefficiencies in executing range queries, as the database might need to scan multiple partitions instead of focusing on a specific range within a partition.

## Conclusion

In conclusion, the implementation of hash partitioning in the inventory management system improves data organization, access speed, and overall performance, especially for large datasets. By leveraging partitioning techniques, the system can efficiently handle the storage, retrieval, and management of inventory data, ensuring optimal performance and scalability. To improve overall architecture in all fronts, adjustments can be made to the partitioning strategy or table structure based on specific requirements and performance considerations.













