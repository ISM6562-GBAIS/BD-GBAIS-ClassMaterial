### Abhijit Vilas Wayal - U09616725

# TITLE : Assignment 2 - Creating a Partitioned Inventory Table in PostgreSQL

In this assignment, I applied my knowledge of PostgreSQL and table partitioning to design an efficient inventory management system for a retail business. I implemented hash partitioning, a key database optimization technique, to distribute rows across partitions based on the hash value of a specified column.

## Design a Inventory Table:
Creating a inventory table with columns : item_id, item_name, quantity, category, warehouse_id

```SQL
CREATE TABLE inventory (
    item_id INTEGER PRIMARY KEY,
    item_name TEXT,
    quantity INTEGER,
    category TEXT,
    warehouse_id INTEGER
) PARTITION BY HASH(item_id);
```
## Implement Hash Partitioning:

Using Hash method we are creating two partitions: inventory_part1 and inventory_part2.

```SQL
CREATE TABLE inventory_part1 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2 PARTITION OF inventory FOR VALUES WITH (MODULUS 2, REMAINDER 1);
```
## Insert Sample Data:

Inserting 5 sample data to check the partitioning.

```SQL
INSERT INTO inventory (item_id, item_name, quantity, category, warehouse_id)
values (1, 'Soccer Ball', 10, 'sports', 11),
(2, 'BaskeBall', 22, 'sports', 12),
(3, 'Cricket Ball', 23, 'sports', 13),
(4, 'Tennis', 25, 'sports', 14),
(5, 'Bat', 26, 'sports', 15);
```

## Querying the Data:
Query to select all items from both partitions

```SQL
SELECT * FROM inventory_part1
```

OUTPUT: 
| item_id | item_name | quantity | category | warehouse_id |
| -- | -- | -- | -- | -- |
| 1 | Soccer Ball | 10 | sports | 11 |
| 2 | BaskeBall | 22 | sports | 12 |

```SQL
SELECT * FROM inventory_part2
```
OUTPUT: 
| item_id | item_name | quantity | category | warehouse_id |
| -- | -- | -- | -- | -- |
| 3 | Cricket Ball | 23 | sports | 13 |
| 4 | Tennis | 25 | sports | 14 |
| 5 | Bat | 26 | sports | 15 |

Query to count the number of items in each partition

```SQL
SELECT count(*) FROM inventory_part1
```
OUTPUT
| count |
| -- |
| 2 |


```SQL
SELECT count(*) FROM inventory_part2
```
OUTPUT
| count |
| -- |
| 3 |

## Conclusion

Partitioning divides large tables into smaller, more manageable parts based on given criteria. 

Hash partitioning distributes data evenly across partitions using a hash function applied to a chosen column. This improves query performance and scalability by balancing the workload across partitions. A hash function takes an input and produces a fixed-size string of characters, known as a hash value or hash code. 

I thought, item_id 2 and 4 will be in one partition and remaining ones in others. However that was not the case here, because while calculating hash value entire row was consider, and not just the given specific column(item_id).
