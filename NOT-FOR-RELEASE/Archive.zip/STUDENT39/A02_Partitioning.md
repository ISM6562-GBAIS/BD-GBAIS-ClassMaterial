# A2 Partitioning
Week-3,     ISM6562 Big Data
Student: Xintong Zou (U84687321)

## Step1. Design an Inventory Table:

--Create the main inventory table

CREATE TABLE inventory(  
    item_id INT PRIMARY KEY,      
	item_name TEXT,  
    quantity INT,   
	category TEXT,  
	warehouse_id INT    
)   
PARTITION BY HASH (item_id);



## Step2. Implement Hash Partitioning:

--Create partitions

CREATE TABLE inventory_part1   
    PARTITION OF inventory    
    FOR VALUES WITH (MODULUS 2, REMAINDER 0);

CREATE TABLE inventory_part2   
	PARTITION OF inventory   
    FOR VALUES WITH (MODULUS 2, REMAINDER 1);	


## Step3. Insert Sample Data:

--Insert sample data	

INSERT INTO inventory ( item_id, item_name, quantity, category, warehouse_id) VALUES  
(1, 'Apple', 1000, 'Fruit', 101),   
(2, 'Grape', 4000, 'Fruit', 101),   
(3, 'Orange', 3000, 'Fruit', 101),  
(4, 'Eggplant', 5000, 'Vegetable', 102),    
(5, 'Celery', 2000, 'Vegetable',102);


## Step4. Querying the Data:

--Query to select all items from a specific category across all partitions

SELECT * FROM inventory WHERE category = 'Fruit';   
SELECT * FROM inventory WHERE category = 'Vegetable';

--Query to count the number of items in each partition

SELECT count(* ) AS num_items_part1 FROM inventory_part1   
UNION ALL   
SELECT count(* ) AS num_items_part2  FROM inventory_part2;


## Step5. Discussion

Explanation:

Step 1: A table called "Inventory" was created with columns such as item_id, item_name, quantity, category, and warehouse_id.

Step 2: The "Inventory" table was partitioned using hash partitioning based on the item_id column.

Step 3: To demonstrate the functionality of the "Inventory" table, five records were inserted into it.

Step 4: Two queries were provided to retrieve data from the "Inventory" table.

Assumptions:

1. All columns required will be included in the "Inventory" table.
2. The hash function used will distribute records evenly across partitions, which will help in efficient data retrieval based on the hash value calculated from the item_id.
3. The sample data inserted in the "Inventory" table will represent different categories and warehouse locations.
4. The two queries provided will return the expected results. When the 'Fruit' category is queried, all fruit inventory information will be retrieved, the same as the 'Vegetable' category.
